<?php
defined('_JEXEC') or die('Restricted access');
?>
<div class="fadeimages" id="fadeimages" />
